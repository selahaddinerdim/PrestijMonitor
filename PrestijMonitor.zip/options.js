function loadDisplays() {
  chrome.system.display.getInfo((displays) => {
    const monitorSelect = document.getElementById("monitorIndex");
    monitorSelect.innerHTML = "";
    displays.forEach((display, index) => {
      const option = document.createElement("option");
      option.value = index;
      option.textContent = `Monitör ${index + 1} - ${display.bounds.width}x${display.bounds.height}`;
      monitorSelect.appendChild(option);
    });
  });
}

function loadRules() {
  chrome.storage.local.get("rules", (data) => {
    const rules = data.rules || [];
    const ruleList = document.getElementById("ruleList");
    ruleList.innerHTML = "";
    rules.forEach((rule, index) => {
      const li = document.createElement("li");
      li.textContent = `${rule.matchType === "contains" ? "*" : "=="} ${rule.url} → Monitör ${parseInt(rule.monitorIndex) + 1}`;
      const del = document.createElement("button");
      del.textContent = "Sil";
      del.onclick = () => {
        rules.splice(index, 1);
        chrome.storage.local.set({ rules }, loadRules);
      };
      li.appendChild(del);
      ruleList.appendChild(li);
    });
  });
}

document.getElementById("addRule").onclick = () => {
  const url = document.getElementById("url").value.trim();
  const matchType = document.getElementById("matchType").value;
  const monitorIndex = document.getElementById("monitorIndex").value;

  if (!url) return;

  chrome.storage.local.get("rules", (data) => {
    const rules = data.rules || [];
    rules.push({ url, matchType, monitorIndex });
    chrome.storage.local.set({ rules }, loadRules);
  });
};

document.getElementById("refreshMonitors").onclick = () => {
  loadDisplays();
};

loadDisplays();
loadRules();