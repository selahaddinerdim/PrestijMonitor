function applyRuleToTab(tab) {
  if (!tab || !tab.url) return;

  chrome.storage.local.get("rules", (data) => {
    const rules = data.rules || [];
    for (const rule of rules) {
      const match = rule.matchType === "contains"
        ? tab.url.includes(rule.url)
        : tab.url === rule.url;

      if (match) {
        chrome.system.display.getInfo((displays) => {
          const display = displays[rule.monitorIndex];
          if (!display) return;

          chrome.windows.update(tab.windowId, {
            left: display.bounds.left,
            top: display.bounds.top,
            width: display.bounds.width,
            height: display.bounds.height,
            state: "normal"
          }, () => {
            chrome.windows.update(tab.windowId, {
              state: "fullscreen"
            });
          });
        });
        break;
      }
    }
  });
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete") {
    applyRuleToTab(tab);
  }
});

chrome.tabs.onActivated.addListener((activeInfo) => {
  chrome.tabs.get(activeInfo.tabId, applyRuleToTab);
});